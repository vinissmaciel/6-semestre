/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tcp;

/**
 *
 * @author Vinicius
 */
import java.io.*;
import java.net.*;

public class TCPServer {

    private static int clientCount = 0;

    public static void main(String args[]) {

        try {

// Criação do socket do Servidor, utilizando a porta serverPort.
            int serverPort = 8000;
            ServerSocket listenSocket = new ServerSocket(serverPort);
            System.out.println("Sever inicializado");

// Loop principal de espera por novos Clientes.            
            while (true) {

// Servidor aguarda a conexão de algum Cliente.
                Socket clientSocket = listenSocket.accept();
                DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
                int clientId = ++clientCount;
                // Envia a mensagem de boas-vindas para o cliente
                out.writeUTF("Bem-vindo ao servidor de cálculo de nota mínima na prova final! Seu ID de cliente é: " + clientId);

// Criação da Thread e conexão desta ao socket do Cliente.
                ConnectionTCP c = new ConnectionTCP(clientSocket, clientId);
                System.out.println("Conectou! o cliente " + clientId);
            }
        } catch (IOException e) {
            System.out.println("Listen: " + e.getMessage());
        }
    }
}

class ConnectionTCP extends Thread {

    DataInputStream in;
    DataOutputStream out;
    Socket clientSocket;
    int clientId;
    int erro;

// Conexão da Thread-Servidora com o socket do Cliente e
// criação dos fluxos de I/O. (início)    
    public ConnectionTCP(Socket aClientSocket, int clientId) {
        try {
            clientSocket = aClientSocket;
            in = new DataInputStream(clientSocket.getInputStream());
            out = new DataOutputStream(clientSocket.getOutputStream());
            this.clientId = clientId;
            this.start();
        } catch (IOException e) {
            System.out.println("Connection: " + e.getMessage());
        }
    }
// Conexão da Thread-Servidora com o socket do Cliente e
// criação dos fluxos de I/O. (final)     

// Conversa entre a Thread-Servidor com o Cliente. (início)
    public void run() {
        try {
            // Recebe as três notas do cliente
            
            double nota1 = in.readDouble();
            double nota2 = in.readDouble();
            double nota3 = in.readDouble();
            
            if((nota1 < 0 || nota1 > 10) || (nota2 < 0 || nota2 > 10) ||(nota3 < 0 || nota3 > 10)){
                erro=1;
            }

            // Calcula a média das notas
            double media = (nota1 + nota2 + nota3) / 3.0;
            // Calcula quanto precisa tirar na prova final
            double nota_final = (50-7*media)/3.0;

            // Envia a nota da prova final de volta para o cliente
            if(erro == 1){
                out.writeUTF("Notas inválidas!");
                System.out.println(clientId + " informou notas inválidas!");
            }else if(media < 20.0/7.0){
                out.writeUTF("Você não pode fazer a prova final pois seu média foi muito baixa!");
                System.out.println(clientId + " teve média muito baixa!");
            }else if(media < 7){
                out.writeUTF("Nota minima na prova final recebida do servidor: "+nota_final);
                System.out.println("Nota enviada para o cliente " + clientId + ": " + nota_final);
            }else{
                out.writeUTF("Você passou!");
                System.out.println(clientId + " passou!");
            }
        } catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.out.println("IO: " + e.getMessage());
            }
        }
    }
}
