 import java.io.* ;
 import java.net.* ;
import javax.swing.JOptionPane;

 
 public class TCPClient
 {
    public static void main (String args[]){
         
 // Criação do socket do Cliente, acessando o endereço/porta do Servidor  e
 // criação dos fluxos de I/O. (início)
        Socket s = null;
        try{
            int serverPort=8000;
            s = new Socket("127.0.0.1", serverPort);
            DataInputStream in = new DataInputStream( s.getInputStream());
            String welcomeMessage = in.readUTF();
            JOptionPane.showMessageDialog(null, welcomeMessage);
            DataOutputStream out = new DataOutputStream( s.getOutputStream());
            try{
                // Conversa entre o Cliente e o Servidor. (início)
                 //Solicitação de notas do client
                double nota1 = Double.parseDouble(JOptionPane.showInputDialog("Digite a primeira nota: "));
                double nota2 = Double.parseDouble(JOptionPane.showInputDialog("Digite a segunda nota: "));
                double nota3 = Double.parseDouble(JOptionPane.showInputDialog("Digite a terceira nota: "));
                
                // Envia as três notas para o servidor
                out.writeDouble(nota1);
                out.writeDouble(nota2);
                out.writeDouble(nota3);
            }catch(IOException e){
                System.out.println("IO:" + e.getMessage());
            }

 // Criação do socket do Cliente, acessando o endereço/porta do Servidor  e
 // criação dos fluxos de I/O. (final) 
             
 // Recebe a média do servidor
        String media = in.readUTF();
        JOptionPane.showMessageDialog(null, media);
 // Conversa entre o Cliente e o Servidor. (final)            
 
 // Tratamento de Exceções. (início)
        }
        catch (UnknownHostException e)
        {
            System.out.println("Sock:" + e.getMessage());
        }
        catch (EOFException e)
        {
            System.out.println("EOF:" + e.getMessage());
        }
        catch (IOException e)
        {
            System.out.println("IO:" + e.getMessage());
        }
        finally 
        {
            if(s!=null) 
                try 
                {
                    s.close();
                } 
            catch (IOException e)
            {
                System.out.println("IO:"+e.getMessage());
            }
        }
 // Tratamento de Exceções. (final)
     }
 }
