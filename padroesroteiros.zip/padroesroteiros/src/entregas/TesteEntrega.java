/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entregas;

/**
 *
 * @author Vinicius
 */
public class TesteEntrega {
    public static void main(String[] args) { 
        Entrega e = new Sedex();
        //Entrega e = new Azul();
        //Entrega e = new DHL();
        
        Pedido p1 = new Pedido(e, "Carne");
        p1.verificarPedido();
        
        System.out.println("");
        
        Pedido p2 = new Pedido(e, "Arroz");
        p2.verificarPedido();
        
        System.out.println("");
        
        Pedido p3 = new Pedido(e, "Computador");
        p3.verificarPedido();
    }
}
