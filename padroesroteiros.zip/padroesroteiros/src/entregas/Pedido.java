/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entregas;

/**
 *
 * @author Vinicius
 */
public class Pedido {
    private Entrega entrega;
    private String produto;

    public Pedido(Entrega e, String produto) {
        this.entrega = e;
        this.produto = produto;
    }
    
    public void verificarPedido(){ 
        this.entrega.entrega(); 
        System.out.println("Pedido de " + this.produto); 
    }
}
