/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro2.parte4;

/**
 *
 * @author Vinicius
 */
public class BordaPontilhada implements Borda {
    public void gerarBorda(){
        System.out.println("Borda Pontilhada");
    }
}
