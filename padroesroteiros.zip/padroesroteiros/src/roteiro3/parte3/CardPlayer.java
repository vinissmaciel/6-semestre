/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro3.parte3;

/**
 *
 * @author Vinicius
 */
public class CardPlayer extends Player {

    public CardPlayer(String nome) {
        super(nome);
    }

    @Override
    public void definirTatica() {
        System.out.println(super.nome + " - É um jogador muito calmo");
    }
}
