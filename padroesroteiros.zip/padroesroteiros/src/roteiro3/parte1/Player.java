/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro3.parte1;

/**
 *
 * @author Vinicius
 */
public abstract class Player {

    protected String nome;

    public Player(String nome) {
        this.nome = nome;
    }

    public void treinar() {
        System.out.println(this.nome + " Executando o treino !");
    }

    public void estiloCompetidor() {
        System.out.println(this.nome + " Muito competitivo !");
    }

    public abstract void definirTatica();
}
