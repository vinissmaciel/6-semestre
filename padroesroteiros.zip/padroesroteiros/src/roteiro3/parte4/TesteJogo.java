/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro3.parte4;

/**
 *
 * @author Vinicius
 */
public class TesteJogo {

    public static void main(String[] args) {
        
        RunFast correRapido = new RunFast();
        RunNoWay naoCorre = new RunNoWay();

        System.out.println("Detalhes do Jogador de Tenis");
        TennisPlayer guga = new TennisPlayer("Gustavo Kuerten", correRapido);
        guga.treinar();
        guga.estiloCompetidor();
        guga.definirTatica();
        guga.correr();
        System.out.println("******************");
        
        System.out.println("Detalhes do Jogador de Futebol");
        SoccerPlayer ronaldo = new SoccerPlayer("Ronaldinho Gaucho", correRapido);
        ronaldo.treinar();
        ronaldo.estiloCompetidor();
        ronaldo.definirTatica();
        ronaldo.correr();
        System.out.println("******************");
        
        System.out.println("Detalhes do Jogador de Cartas");
        CardPlayer joseCartas = new CardPlayer("Jose das Cartas", naoCorre);
        joseCartas.treinar();
        joseCartas.estiloCompetidor();
        joseCartas.definirTatica();
        joseCartas.correr();
        System.out.println("******************");
        
        System.out.println("Detalhes do Jogador de Xadrez");
        ChessPlayer kasparov = new ChessPlayer("Kasparov", naoCorre);
        kasparov.treinar();
        kasparov.estiloCompetidor();
        kasparov.definirTatica();
        kasparov.correr();
        System.out.println("******************");
        
        System.out.println("Detalhes do Jogador de Golf");
        GolfPlayer tigerwoods = new GolfPlayer("Tiger Woods", naoCorre);
        tigerwoods.treinar();
        tigerwoods.estiloCompetidor();
        tigerwoods.definirTatica();
        tigerwoods.correr();
        System.out.println("******************");
        
        /*
        11 – Faça a correspondência entre as classes, comparando o diagrama formal do padrão Strategy e as classes que acabamos de modelar neste projeto.
        
        Resposta:
        
                Client -> Player
                Strategy -> RunBehavior
                ConcreteStrategy1 -> RunFast
                ConcreteStrategy2 -> RunNoWay
        
        12 – Neste modelo final em que chegamos, seria possível modificar a habilidade de correr de algum jogador em tempo de execução. Ex.: Um jogador que inicialmente não corre, podemos fazer com que ele passe a correr ? Se sim, como isso poderia ser feito ?
        
        Resposta: Sim. Devemos criar um:
        
                setHabilidadeCorrer(RunBehavior habilidadeCorrer){
                    this.habilidadeCorrer = habilidadeCorrer;
                } 

                na classe Player e chamar esse método em tempo de execução
        */
    }
}
