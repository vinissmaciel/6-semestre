/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro3.parte4;

/**
 *
 * @author Vinicius
 */
public abstract class Player {

    protected String nome;
    protected RunBehavior habilidadeCorrer;

    public Player(String nome, RunBehavior habilidadeCorrer) {
        this.nome = nome;
        this.habilidadeCorrer = habilidadeCorrer;
    }

    public void treinar() {
        System.out.println(this.nome + " Executando o treino !");
    }

    public void estiloCompetidor() {
        System.out.println(this.nome + " Muito competitivo !");
    }

    public void correr() {
        this.habilidadeCorrer.correr();
    }

    public abstract void definirTatica();
}
