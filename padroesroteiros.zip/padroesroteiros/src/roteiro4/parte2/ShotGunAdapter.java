/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro4.parte2;

import armas.artilharia.ShotGun;

/**
 *
 * @author Vinicius
 */
public class ShotGunAdapter extends ShotGun implements Arma {

    @Override
    public void carregar() {
        this.loadGun();
    }

    @Override
    public void atirar() {
        this.shotKill();
    }

    @Override
    public void mirar() {
        this.targetEnemy();
    }
}
