/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro4.parte2;

/**
 *
 * @author Vinicius
 */
public class Teste {

    public static void main(String[] args) {

        Arma pistola = new Pistola();
        Atirador atirador01 = new Atirador("Sniper Joaquim", pistola);
        System.out.println("\n" + atirador01.getNome() + " brincando com a Pistola");
        atirador01.carregarArma();
        atirador01.fazerMira();
        atirador01.usarArma();

        // ****************************************************** 
        Arma fuzil = new Fuzil();
        atirador01.setArma(fuzil);
        System.out.println("\n" + atirador01.getNome() + " brincando com o Fuzil");
        atirador01.carregarArma();
        atirador01.fazerMira();
        atirador01.usarArma();

        // ****************************************************** 
        Arma rifle = new Rifle();
        atirador01.setArma(rifle);
        System.out.println("\n" + atirador01.getNome() + " brincando com o Rifle");
        atirador01.carregarArma();
        atirador01.fazerMira();
        atirador01.usarArma();

        // ****************************************************** 
        Arma shotgun = new ShotGunAdapter();
        atirador01.setArma(shotgun);
        System.out.println("\n" + atirador01.getNome() + " brincando com a ShotGun");
        atirador01.carregarArma();
        atirador01.fazerMira();
        atirador01.usarArma();
        
        /*
            7 – Associe o papel de cada classe do diagrama formal padrão Adapter indicado no início deste documento as classes criadas no nosso roteiro. Ou seja :

            - Quem representa a classe Adapter ?
                Resposta: ShotGunAdapter

            - Quem representa a classe Adaptee ?
                Resposta: ShotGun
        
            - Quem representa a classe Target ?
                Resposta: Arma (Pistola, Rifle e Fuzil)
        
            - Quem representa a classe Client ?
                Resposta: Atirador
        */
    }
}
