/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro4.parte2;

/**
 *
 * @author Vinicius
 */
public class Rifle implements Arma {

    @Override
    public void carregar() {
        System.out.println("Carregando o Rifle");
    }

    @Override
    public void atirar() {
        System.out.println("Tiro com rifle não falha");
    }

    @Override
    public void mirar() {
        System.out.println("Zoom no alvo");
    }
    
}
