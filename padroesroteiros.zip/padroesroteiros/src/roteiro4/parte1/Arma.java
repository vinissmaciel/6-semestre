/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro4.parte1;

/**
 *
 * @author Vinicius
 */
public interface Arma {
    public void carregar();
    
    public void atirar();
    
    public void mirar();
}
