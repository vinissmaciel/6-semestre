/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro6.parte2;

/**
 *
 * @author Vinicius
 */
public class TesteComFacade {

    public static void main(String[] args) {
        Facade facade = new Facade();
        facade.registrarCliente("Jose", 222);
        
        facade.comprar(1, 222);
        facade.comprar(2, 222);
        facade.finalizarCompra(222);
        
        /*
            6 – Faça uma analise comparativa entre as classes TesteSemFacade e TesteComFacade.Avalie vantagens e desvantagens. 
                Avalie possíveis impactos no caso de uma mudança na regra de negócio do sistema.
                
            Resposta: A classe TesteComFacade tem um código muito mais legível, além de que só é preciso instanciar a classe Facade.
                      A clase TesteSemFacade tem um código confuso, e é preciso instanciar todas as classes.
                      Mudanças na regra de negócio do sistema na classe TesteSemFacade são feitas diretamente no seu código podendo 
                      gerar confusão por conta da quantidade de instâncias (ex: 100 clientes e 500 produtos), enquanto
                      na classe TesteComFacade as mudanças devem ser feitas na classe Facade e servirão para todos os casos.
        */
    }
}
