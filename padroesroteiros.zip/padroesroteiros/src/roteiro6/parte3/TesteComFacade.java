/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro6.parte3;


/**
 *
 * @author Vinicius
 */
public class TesteComFacade {

    public static void main(String[] args) {
        Facade facade = new Facade();
        facade.registrarCliente("Jose", 222);
        
        facade.comprar(1, 222);
        facade.comprar(2, 222);
        facade.finalizarCompra(222);
        
        /*
            4 – Faça uma pequena pesquisa e registre aqui o seu entendimento sobre Coesão x Acoplamento
                
            Resposta: 
                Coesão: Uma classe deve ter apenas uma única responsabilidade e realizá-la de maneira satisfatória, ou seja, uma classe não deve assumir responsabilidades que não são suas.
                Acoplamento: O quanto uma classe depende da outra para funcionar.
        
            5 – Faça uma pequena pesquisa sobre Lei de Demetrio (Lei de Demeter) ou Princípio do Conhecimento mínimo e registre aqui o seu entendimento.
                
            Resposta: Lei de Demetrio ou O Princípio do Mínimo Conhecimento nos orienta a reduzir as interações entre os objetos, aconselhando-nos ao encapsulamento de funções, rotinas, lógicas internas e sistemas. Um sistema com muitas dependências entre múltiplas classes é um sistema frágil, de difícil manutenção e complexo demais para ser compreendido por todos.
        
            6 – Qual associação você faz sobre a evolução do nosso projeto e as suas pesquisas feitas nas questões 4 e 5 ? Estes princípios e práticas de engenharia de software foram aplicados ? Como ?
                
            Resposta: Na primeira parte, o sistema está muito interdependente, as classes precisam das outras para funcionar. A linha de código a seguir demonstra isto:
                        cli01.getCarrinho().addProduto(p1);
                      Um objeto Cliente chama um Objeto Carrinho para adicionar um Produto. Isso fere a Lei de Demeter e a coesão, pois a partir de um Cliente nós
                      acessamos um método de um CarrinhoCompra.
        
                      A criação da classe Facade na segunda parte ajuda a centralizar as atividades e diminuir a interdependencia, já que todas as regras de negócio são
                      chamadas por Facade, diminuindo o acoplamento entre Cliente e as outras classes. Porém ainda acontece de acessarmos o método de CarrinhoCompra por um objeto de Cliente. Isso só é resolvido na parte 3, quando
                      tiramos a instância de CarrinhoCompra de Facade e fazemos inicialzação do carrinho e o cálculo do total da compra no Cliente. A coesão do projeto ainda é questionável, visto
                      que o cálculo do valor de um Carrinho é feito na classe Cliente.
        */
    }
}
