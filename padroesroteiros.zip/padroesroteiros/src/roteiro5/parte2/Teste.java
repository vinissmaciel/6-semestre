/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package roteiro5.parte2;

/**
 *
 * @author 072120131
 */
public class Teste {

    public static void main(String[] args) {
        ControladorAereo c1 = ControladorAereo.getInstace();
        ControladorAereo c2 = ControladorAereo.getInstace();
        c1.solicitarDecolagem();
        c2.solicitarDecolagem();
        System.out.println(" ");
        c1.solicitarAterrissagem();
        c2.solicitarAterrissagem();
    }
    
    /*
        4 – O resultado saiu como esperado conforme descrito no cenário? Sim/Não e porquê?
    
        Resposta: Sim, pois agora uma aterrissagem só é concedida na sequência de uma decolagem e vice-versa. 
    */
}
