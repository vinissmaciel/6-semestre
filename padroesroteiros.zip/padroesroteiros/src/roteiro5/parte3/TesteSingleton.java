package roteiro5.parte3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author 072120131
 */
public class TesteSingleton {

    public static void main(String[] args) {
        InocenteSingleton n1 = InocenteSingleton.getInstance();
        InocenteSingleton n2 = InocenteSingleton.getInstance();
        System.out.println(n1 == n2 ? "Instâncias iguais" : "Instâncias diferentes");

        /*
            4 – O resultado saiu como esperado conforme o Padrão Singleton descreve? Sim/Não e porquê?
        
            Resposta: Não, pois tem duas instâncias diferentes da classe, o padrão Singleton assegura que tenha apenas uma instância da classe.  
         */
        
        LazySingleton n3 = LazySingleton.getInstance();
        LazySingleton n4 = LazySingleton.getInstance();
        System.out.println(n3 == n4 ? "Instâncias iguais" : "Instâncias diferentes");

        /*
            7 – Qual é a sua analise sobre os resultados apresentados para as variáveis n1, n2, n3 e n4 ?
        
            Resposta: n1 e n2 são instâncias diferentes, pois o getInstance() da classe InocenteSingleton sempre cria uma instância nova da classe, fora do padrão Singleton.
                      n3 e n4 são instâncias iguais, pois o getInstance() da classe LazySingleton verifica se já existe uma instância da classe. Se já existir, ele retorna a instância, se não existir, ele cria a instância e retorna, garantindo o padrão Singleton.
         */
        
        EagerSingleton n5 = EagerSingleton.getInstance();
        EagerSingleton n6 = EagerSingleton.getInstance();
        System.out.println(n5 == n6 ? "Instâncias iguais" : "Instâncias diferentes");
    
        /*
            10 – Qual dos padrões (Lazy Singleton ou Eager Singleton) foi utilizado no cenário do controlador de vôo do pacote 2 ?
        
            Resposta: Eager Singleton.
         */
        
        StaticSingleton n7 = StaticSingleton.instance;
        StaticSingleton n8 = StaticSingleton.instance;
        System.out.println(n7 == n8 ? "Instâncias iguais" : "Instâncias diferentes");
    }
}
