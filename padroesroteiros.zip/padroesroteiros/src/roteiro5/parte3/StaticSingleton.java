/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package roteiro5.parte3;

/**
 *
 * @author 072120131
 */
public class StaticSingleton {
    public static final StaticSingleton instance = new StaticSingleton();
}
