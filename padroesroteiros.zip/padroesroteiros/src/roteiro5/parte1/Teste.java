/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package roteiro5.parte1;

/**
 *
 * @author 072120131
 */
public class Teste {

    public static void main(String[] args) {
        ControladorAereo c1 = new ControladorAereo();
        ControladorAereo c2 = new ControladorAereo();
        c1.solicitarDecolagem();
        c2.solicitarDecolagem();
        System.out.println(" ");
        c1.solicitarAterrissagem();
        c2.solicitarAterrissagem();
    }
    
    /*
        4 – O resultado saiu como esperado conforme descrito no cenário? Sim/Não e porquê?
    
        Resposta: Não, pois duas decolagens foram concedidas em sequência quando só poderia ser concecida uma aterrissagem na sequência de uma decolagem. 
    */
}
