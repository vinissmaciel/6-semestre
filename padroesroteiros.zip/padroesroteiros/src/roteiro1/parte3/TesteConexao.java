/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro1.parte3;

/**
 *
 * @author Vinicius
 */
public class TesteConexao {
    public static void main(String[] args) { 
        
        Connection c = new MysqlConnection(); 
        //Connection c = new OracleConnection(); 
        //Connection c = new SQLServerConnection(); 
        
        ServicoQuarto quarto = new ServicoQuarto(c); 
        quarto.verificarQuarto(); 
        
        ServicoReserva reserva = new ServicoReserva(c); 
        reserva.criarReserva(); 
        
        RelatorioReserva relatorio = new RelatorioReserva(c); 
        relatorio.gerarRelatorio(); 
    }
}
