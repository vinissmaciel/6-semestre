/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package roteiro7.parte1;



/**
 *
 * @author Vinicius
 */
public class TesteComFacade {

    public static void main(String[] args) {
        Facade facade = Facade.getInstance();
        facade.registrarCliente("Jose", 222);
        
        facade.comprar(1, 222);
        facade.comprar(2, 222);
        facade.finalizarCompra(222);
        
        /*
            4 – Depois de implementar o item 3, explique quais seriam as funções desta classe que o item 3 se refere.
                
            Resposta: A classe Facade agora serve como instância única e ponto de acesso global, como assegura o padrão Singleton. Além disso,
                      a classe também funciona como uma interface intermediária entre o subsistema de compras e cliente, de acordo com o padrão Facade.
        
        */
    }
}
